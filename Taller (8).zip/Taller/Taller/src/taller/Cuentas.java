
package taller;

public class Cuentas {
    private String nombreCuenta;
    private String contraseña;
    private String nick;
    private int nivelCuenta;
    private int rp;
    private int totalPersonajes;
    private String nombrePersonaje;
    private int cantSkin;
    private String nombreSkin;
    private String region;

    public Cuentas(String nombreCuenta, String contraseña, String nick, int nivelCuenta, int rp, int totalPersonajes, String nombrePersonaje, int cantSkin, String nombreSkin, String region) {
        this.nombreCuenta = nombreCuenta;
        this.contraseña = contraseña;
        this.nick = nick;
        this.nivelCuenta = nivelCuenta;
        this.rp = rp;
        this.totalPersonajes = totalPersonajes;
        this.nombrePersonaje = nombrePersonaje;
        this.cantSkin = cantSkin;
        this.nombreSkin = nombreSkin;
        this.region = region;
    }

    public String getNombreCuenta() {
        return nombreCuenta;
    }

    public void setNombreCuenta(String nombreCuenta) {
        this.nombreCuenta = nombreCuenta;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public int getNivelCuenta() {
        return nivelCuenta;
    }

    public void setNivelCuenta(int nivelCuenta) {
        this.nivelCuenta = nivelCuenta;
    }

    public int getRp() {
        return rp;
    }

    public void setRp(int rp) {
        this.rp = rp;
    }

    public int getTotalPersonajes() {
        return totalPersonajes;
    }

    public void setTotalPersonajes(int totalPersonajes) {
        this.totalPersonajes = totalPersonajes;
    }

    public String getNombrePersonaje() {
        return nombrePersonaje;
    }

    public void setNombrePersonaje(String nombrePersonaje) {
        this.nombrePersonaje = nombrePersonaje;
    }

    public int getCantSkin() {
        return cantSkin;
    }

    public void setCantSkin(int cantSkin) {
        this.cantSkin = cantSkin;
    }

    public String getNombreSkin() {
        return nombreSkin;
    }

    public void setNombreSkin(String nombreSkin) {
        this.nombreSkin = nombreSkin;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
    
    
}
