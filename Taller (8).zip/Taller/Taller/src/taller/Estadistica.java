
package taller;

public class Estadistica {
    private String estdPersonaje;
    private int recuadacion;

    public Estadistica(String estdPersonaje, int recuadacion) {
        this.estdPersonaje = estdPersonaje;
        this.recuadacion = recuadacion;
    }

    public String getEstdPersonaje() {
        return estdPersonaje;
    }

    public void setEstdPersonaje(String estdPersonaje) {
        this.estdPersonaje = estdPersonaje;
    }

    public int getRecuadacion() {
        return recuadacion;
    }

    public void setRecuadacion(int recuadacion) {
        this.recuadacion = recuadacion;
    }
    
    
}
