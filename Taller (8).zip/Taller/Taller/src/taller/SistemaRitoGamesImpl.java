
package taller;

public class SistemaRitoGamesImpl implements SistemaRitoGames {
    private ListaCuentas lc;
    private ListaPersonajes lp;
    private ListaEstadistica listaE;
    
    public SistemaRitoGamesImpl(){
        this.lc = new ListaCuentas(999);
        this.lp = new ListaPersonajes(155);
        this.listaE = new ListaEstadistica(155);
    }
    @Override
   public boolean ingresarEstadistica(Estadistica e) {
        if(listaE.insertar(e)){
            return true;
        }else{
            return false;
        }
    }
    @Override
   public boolean ingresarPersonaje(Personajes p) {
        if(lp.insertar(p)){
            return true;
        }else{
            return false;
        }
    }
    @Override
    
   public boolean ingresarCuenta(Cuentas c) {
        if(lc.insertar(c)){
            return true;
        }else{
            return false;
        }
    }
    
    @Override
    public void eliminarCuenta(String nombreCuenta) {
        Cuentas cuenta = lc.buscarNombreCuenta(nombreCuenta);
        if (cuenta == null) {
            throw new NullPointerException("No existe la cuenta a eliminar.");
            }
        else {
            lc.eliminarCuenta(nombreCuenta);
        }
    }
    @Override
    public String obtenerDatosCuentas() {
        String salida = "\nListado de Cuentas\n";
        for(int i = 0; i < lc.getCantidadCuentas(); i++) {
            
            Cuentas cuenta = lc.getCuenta(i);
            salida = salida + "Nombre de cuenta "+ cuenta.getNombreCuenta() + ", Nick "+ cuenta.getNick()+ ", Contraseña "+ cuenta.getContraseña();
            
            salida = salida + "\n";
        }
        return salida;
    }
    
    @Override
    public String obtenerDatosPersonajes() {
        String salida = "\nListado de personajes\n";
        for(int i = 0; i < lp.getCantidadPersonajes(); i++) {
            
            Personajes personaje = lp.getPersonajeI(i);
            salida = salida + "Nombre de personaje: "+ personaje.getNombreP() + ", rol: "+ personaje.getRolP()+ ", nombre Skin: "+ personaje.getNomSkin()+", calidad"+personaje.getCalidad();
            
            salida = salida + "\n";
        }
        return salida;
    }

}
