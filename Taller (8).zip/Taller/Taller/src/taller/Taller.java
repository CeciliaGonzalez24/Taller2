package taller;
import ucn.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.util.Scanner;
public class Taller {

    public static void decorador(){
        String decorador ="__________________________________________";
        StdOut.println(decorador);
    }
    
    public static void leerTXT(SistemaRitoGames sistema) throws FileNotFoundException, IOException{
        File f = new File("Personajes.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String linea = br.readLine();
        
        while(linea != null){
            
            String [] partes = linea.split(",");
            
            String nombre = partes[0];
            String rol= partes[1];
            int cantSkins = Integer.parseInt(partes[2]);
            
            if(cantSkins ==1){
                String nombreSkin= partes[3];
                String calidad= partes[4];
                Personajes nueva = new Personajes(nombre,rol,cantSkins,nombreSkin,calidad);
                sistema.ingresarPersonaje(nueva);
                /*if(sistema.ingresarPersonaje(nueva)){
                        System.out.println("Nombre del personaje "+nueva.getNombreP()+" con calidad "+nueva.getNomSkin());
                }else{
                    System.out.println("Error en el sistema, comuniquese con mantención, no se pudo ingresar a: "+nueva.getNomSkin());
                }*/
                
            }
            else{
                int j=2;
                for(int i=0; i<cantSkins;i++){
                    
                    String nombreSkin= partes[j+1];
                    String calidad= partes[j+2]; 
                    j+=2;
                    Personajes nueva = new Personajes(nombre,rol,cantSkins,nombreSkin,calidad);
                    sistema.ingresarPersonaje(nueva);
                    /*if(sistema.ingresarPersonaje(nueva)){
                        System.out.println("Nombre del personaje "+nueva.getNombreP()+" con calidad "+nueva.getNomSkin());
                    }else{
                        System.out.println("Error en el sistema, comuniquese con mantención, no se pudo ingresar a: "+nueva.getNomSkin());
                    }*/
                    
                }
                
            }
            
            linea = br.readLine();
            
        }
    }
    
    public static void leerTXT2(SistemaRitoGames sistema) throws FileNotFoundException, IOException{
        File f2 = new File("Cuentas.txt");
        FileReader fr = new FileReader(f2);
        BufferedReader br = new BufferedReader(fr);
        String linea2 = br.readLine();
        
        while(linea2 != null){
            
            String [] partes2 = linea2.split(",");
            
            String nombreCuenta = partes2[0];
            String contrasena= partes2[1];
            String nick = partes2[2];
            int nivelCuenta = Integer.parseInt(partes2[3]);
            
            int rp = Integer.parseInt(partes2[4]);
            int totalPersonajes = Integer.parseInt(partes2[5]);
            int pos=5;
            if(totalPersonajes >155){
                System.out.println("Este usuario tiene más de 155 personajes");
            }
            else{
                int i=0;
                while (i <totalPersonajes){
                    pos++;
                    String nombrePersonaje = partes2[pos];
                    pos++;
                    int cantSkins = Integer.parseInt(partes2[pos]);
                    for(int k=0;k<cantSkins;k++){
                        pos++;
                        String calidad = partes2[pos];
                        //Cuentas nueva = new Cuentas(nombreCuenta,contrasena,nick,nivelCuenta,rp,totalPersonajes, nombrePersonaje,cantSkin,calidad);
                    }
                    i++;   
                } 
            }
            pos++;
            String region = partes2[pos];
            
            linea2 = br.readLine();
        }
    }
    
    public static void leerTXT3(SistemaRitoGames sistema) throws FileNotFoundException, IOException{
        File f = new File("Estadisticas.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String linea = br.readLine();
        
        while(linea != null){
            
            String [] partes = linea.split(",");
            
            String personaje = partes[0];
            int rp = Integer.parseInt(partes[1]);
            
            Estadistica nueva = new Estadistica(personaje,rp);
            sistema.ingresarEstadistica(nueva);
            /*if(sistema.ingresarEstadistica(nueva)){
                System.out.println("Persona de nombre: "+nueva.getEstdPersonaje()+" registrada correctamente");
            }else{
                System.out.println("Error en el sistema, comuniquese con mantención, no se pudo ingresar a: "+nueva.getEstdPersonaje());
            }*/
              
            linea = br.readLine();
            
        }
    }
    
    public static void menu(SistemaRitoGames sistema) throws IOException{
        
        decorador();
        StdOut.println("Bienvenido, ¿A cuál Menú desea ingresar?");
        
        StdOut.println("Opcion 1: Menú de Cliente.");
        StdOut.println("Opcion 2: Menú de Administrador.");
        StdOut.println("Opcion 3: Cerrar el sistema.");
        String opcion = StdIn.readString();
        while(!opcion.equals("3")){
            decorador();
            switch (opcion) {
                case "1":
                    StdOut.println("Bienvenido al menu cliente.");
                    menuCliente(sistema);
                    break;
                    
                case "2":
                    StdOut.println("Bienvenido al menu administrador.");
                    decorador();
                    StdOut.println("Ingrese su nombre de Administrador.");
                    String nombreAdmin = StdIn.readString();
                    StdOut.println("Ingrese su contraseña.");
                    String contraAdmin = StdIn.readString();
                    menuAdmin(nombreAdmin,contraAdmin,sistema); 
                    break;
                default: 
                    StdOut.println("Opcion incorrecta con valor " + opcion);
                    break;
            }
            decorador();

            StdOut.println("Opcion 1: Menú de Cliente.");
            StdOut.println("Opcion 2: Menú de Administrador.");
            StdOut.println("Opcion 3: Cerrar el sistema.");
            opcion = StdIn.readString();
        }
        decorador();
        StdOut.println("Cerrando el sistema, gracias por usarnos.");
        decorador();
    }
    
    public static void menuAdmin(String nombreAdmin, String contraAdmin,SistemaRitoGames sistema) throws IOException{
        
        nombreAdmin = nombreAdmin.toLowerCase();
        contraAdmin = contraAdmin.toLowerCase();
        if (nombreAdmin.equals("admin")&&(contraAdmin.equals("admin"))){
            decorador();
            StdOut.println("Bienvenido al menu de Administrador");
            menuAdmin2(sistema);
        }
        else{
            decorador();
            StdOut.println("No eres Administrador");
        } 
    }
    
    public static void menuAdmin2(SistemaRitoGames sistema) throws IOException{
        decorador();
        StdOut.println("Opcion 1: Desplegar recaudación de ventas por rol.");
        StdOut.println("Opcion 2: Desplegar recaudación total de ventas por región.");
        StdOut.println("Opcion 3: Desplegar recaudación de ventas por personaje.");
        StdOut.println("Opcion 4: Desplegar la cantidad de personajes por cada rol existente.");
        StdOut.println("Opcion 5: Agregar un personaje al juego.");
        StdOut.println("Opcion 6: Agregar un skin.");
        StdOut.println("Opcion 7: Bloquear a un jugador.");
        StdOut.println("Opcion 8: Desplegar todas las cuentas.");
        StdOut.println("Opcion 9: Salir.");
        String opcion = StdIn.readString();
        
        switch (opcion) {
            case "1":
                decorador();
                StdOut.println("Recaudación de ventas por rol.");
                //Para volver a preguntar
                menuAdmin2(sistema);
                break;
            case "2":
                decorador();
                StdOut.println("Desplegar recaudación total de ventas por región.");
                
                //Para volver a preguntar
                menuAdmin2(sistema);
                break;
            case "3":
                decorador();
                StdOut.println("Desplegar recaudación de ventas por personaje.");
                menuAdmin2(sistema);
                break;
            case "4":
                decorador();
                StdOut.println("Desplegar la cantidad de personajes por cada rol existente.");
                menuAdmin2(sistema);
                break;
            case "5":
                decorador();
                StdOut.println("Agregar un personaje al juego.");
                decorador();
                StdOut.println("Ingrese nombre del Personaje");
                String nombre = StdIn.readString();
                
                StdOut.println("Ingrese rol del Personaje");
                String rol = StdIn.readString();
                
                StdOut.println("Ingrese cantidad de Skins del Personaje");
                int cantSkins = StdIn.readInt();
                
                Personajes nueva = new Personajes(nombre,rol,cantSkins,"","");
                sistema.ingresarPersonaje(nueva);
                menuAdmin2(sistema);
                break;
            case "6":
                decorador();
                StdOut.println("Agregar un skin.");
                StdOut.println("Ingrese personaje al cual desea agregarle una Skin.");
                String nombrePersonaje = StdIn.readString();
                menuAdmin2(sistema);
                break;
            case "7":
                decorador();
                StdOut.println("Bloquear a un jugador.");
                eliminarCuenta(sistema);
                menuAdmin2(sistema);
                break;
            case "8":
                decorador();
                StdOut.println("Desplegar todas las cuentas.");
                StdOut.println(sistema.obtenerDatosCuentas());
                menuAdmin2(sistema);
                break;
            case "9":
                decorador();
                StdOut.println("Saliendo del menu administrador.");
                break;
            default:
                decorador();
                StdOut.println("Opcion invalida, intente nuevamente.");
                menuAdmin2(sistema);
                break;
        }
        
    }
    
    public static void menuCliente(SistemaRitoGames sistema)throws IOException{
        decorador();
        StdOut.println("Opcion 1: Iniciar Sesión.");
        StdOut.println("Opcion 2: Registrarse.");
        StdOut.println("Opcion 3: Salir.");
        String sesion = StdIn.readString();
        while(!sesion.equals("3")){
            decorador();
            switch (sesion) {
            case "1":
                StdOut.println("Iniciar Sesion");
                break;
            case "2":
                StdOut.println("Registrarse");
                registrarse(sistema);
                break;
            default:
                StdOut.println("Opcion incorrecta con valor " + sesion);
                break;

                }
            StdOut.println("Opcion 1: Iniciar Sesión.");
            StdOut.println("Opcion 2: Registrarse.");
            StdOut.println("Opcion 3: Salir.");
            sesion = StdIn.readString();
            }
        decorador();
        StdOut.println("Saliendo del menu cliente.");
            
    }
    
    public static void iniciarSesion(SistemaRitoGames sistema)throws IOException{
        
        StdOut.println("Nombre de Cuenta");
        String nombreCuenta = StdIn.readString();
        StdOut.println("Contraseña");
        String contraseña = StdIn.readString();
    }
    
    public static void registrarse(SistemaRitoGames sistema)throws IOException{
        StdOut.println("Nombre de Cuenta");
        String nombreCuenta = StdIn.readString();
        StdOut.println("Contraseña");
        String contraseña = StdIn.readString();
        StdOut.println("Nick");
        String nick = StdIn.readString();
        int rp =0;
        StdOut.println("Region(LAS-LAN-EUW-KR-NA-RU)");
        String region = StdIn.readString();
        
    }
    
    public static void menuCliente2(SistemaRitoGames sistema)throws IOException{
        decorador();
        StdOut.println("Opcion 1: Comprar Skin:.");
        StdOut.println("Opcion 2: Comprar Personaje.");
        StdOut.println("Opcion 3: Skins Disponibles.");
        StdOut.println("Opcion 4: Mostrar Inventario.");
        StdOut.println("Opcion 5: Recargar RP.");
        StdOut.println("Opcion 6: Mostrar Datos de cuenta.");
        StdOut.println("Opcion 7: Salir.");
        String opcion = StdIn.readString();
        
        switch (opcion) {
            case "1":
                decorador();
                StdOut.println("Comprar Skin:.");
                //Para volver a preguntar
                menuCliente2(sistema);
                break;
            case "2":
                decorador();
                StdOut.println("Comprar Personaje.");
                
                //Para volver a preguntar
                menuCliente2(sistema);
                break;
            case "3":
                decorador();
                StdOut.println("Skins Disponibles.");
                menuCliente2(sistema);
                break;
            case "4":
                decorador();
                StdOut.println("Inventario.");
                menuCliente2(sistema);
                break;
            case "5":
                decorador();
                StdOut.println("Recargar RP.");
                menuCliente2(sistema);
                break;
            case "6":
                decorador();
                StdOut.println("Datos de cuenta.");
                StdOut.println(sistema.obtenerDatosCuentas());

                menuCliente2(sistema);
                break;
            case "7":
                decorador();
                StdOut.println("Saliendo del menu Cliente.");
                break;
            
            default:
                decorador();
                StdOut.println("Opcion invalida, intente nuevamente.");
                menuCliente2(sistema);
                break;
        }
        
    }
    
    
    public static void eliminarCuenta(SistemaRitoGames sistemaRitoGames)throws IOException {
        StdOut.println("\nBloqueo de Cuentas");
        StdOut.print("Cuenta, (fin de cuentas a bloquear, cuenta=-99):");
        String cuenta = StdIn.readString();
        while(!cuenta.equals("-99")){
            try {
                sistemaRitoGames.eliminarCuenta(cuenta);
            }
            catch(Exception ex) {
                StdOut.println(ex.getMessage());
            }
            StdOut.print("Cuenta, (fin de cuentas a bloquear, cuenta = -99):");
            cuenta = StdIn.readString();
        }
    }

    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //ISistema sistema = new ISistemaImpl();
        SistemaRitoGames sistema = new SistemaRitoGamesImpl();
        leerTXT(sistema);
        leerTXT2(sistema);
        leerTXT3(sistema);
        menu(sistema);
    }
    
}
