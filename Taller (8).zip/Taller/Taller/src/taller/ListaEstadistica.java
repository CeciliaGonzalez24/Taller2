
package taller;

public class ListaEstadistica {
    private int max;
    private int cantidadEstadistica;
    private Estadistica[] listaE;

    public ListaEstadistica(int max) {
        this.max = max;
        cantidadEstadistica = 0;
        listaE = new Estadistica[max];
    }
    
    /**
     * Function that allows adding a new container with the data.
     * @param e Container with data.
     * @return Returns a boolean according to the result.
     */
    public boolean insertar(Estadistica e){
        if(cantidadEstadistica < max){
            this.listaE[cantidadEstadistica] = e;
            cantidadEstadistica++;
            return true;
        }
        return false;
    }
    
    /**
     * Function that allows you to search for the character within the list.
     * @param estdPersonaje Variable used to search within the list.
     * @return Returns the position within the list or null otherwise.
     */
    public Estadistica buscarPersonaje(String estdPersonaje) {
        int i = 0;
        while(i<cantidadEstadistica&&!listaE[i].getEstdPersonaje().equals(estdPersonaje)){
            i++;
        }
        if (i == cantidadEstadistica) {
             return null;
        }   
        else {
            return listaE[i];
        }
    }
    
    public Estadistica getPersonajeI(int i) {
        if (i >= 0 && i < cantidadEstadistica) {
            return listaE[i];
        }
        else {
            return null;
        }
    }

    public int getCantidadEstadistica() {
        return cantidadEstadistica;
    }

    public void setCantidadEstadistica(int cantidadEstadistica) {
        this.cantidadEstadistica = cantidadEstadistica;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public Estadistica[] getListaE() {
        return listaE;
    }

    public void setListaE(Estadistica[] listaE) {
        this.listaE = listaE;
    }
        
}
