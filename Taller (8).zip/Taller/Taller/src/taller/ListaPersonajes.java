
package taller;

public class ListaPersonajes {  
    private int max;
    private Personajes[] lp;
    private int cantidadPersonajes;
   

    public ListaPersonajes(int max) {
        this.max = max;
        lp = new Personajes[max];
        cantidadPersonajes = 0;    
    }
    /**
     * Function that saves the new container in the list of characters, updating the list.
     * @param p Character data container.
     * @return Returns True or False when the container with the data is saved or not.
     */
    public boolean insertar(Personajes p){
        if(cantidadPersonajes < max){
            this.lp[cantidadPersonajes] = p;
            cantidadPersonajes++;
            return true;
        }
        return false;
    }
  
    public int getCantidadPersonajes() {
        return cantidadPersonajes;
    }
    
    public void setCantidadPersonajes(int cantidadPersonajes) {
        this.cantidadPersonajes = cantidadPersonajes;
    }

    /**
     * Function that allows you to search for the position within the list.
     * @param nombreP Variable that is used to find the position where it is in the list.
     * @return Returns the position where the character's name is found.
     */
    public Personajes buscarPersonaje(String nombreP){
        int i=0;
        while(i<cantidadPersonajes&&!lp[i].getNombreP().equals(nombreP)){
            i++;
        }
        if(i==cantidadPersonajes){
            return null;
        }
        else{
            return lp[i];
        }
    }
    
    public Personajes getPersonajeI(int i){
        if(i>=0&&i<cantidadPersonajes){
            return lp[i];
        }
        else{
            return null;
        }
    }
    
    public Personajes buscarSkin(String nomSkin){
        int i=0;
        while(i<cantidadPersonajes&&!lp[i].getNomSkin().equals(nomSkin)){
            i++;
        }
        if(i==cantidadPersonajes){
            return null;
        }
        else{
            return lp[i];
        }
    }
    
    public Personajes getSkinI(int i){
        if(i>=0&&i<cantidadPersonajes){
            return lp[i];
        }
        else{
            return null;
        }
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public Personajes[] getLp() {
        return lp;
    }

    public void setLp(Personajes[] lp) {
        this.lp = lp;
    }
    
    
}
