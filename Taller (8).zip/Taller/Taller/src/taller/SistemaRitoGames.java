
package taller;

public interface SistemaRitoGames {
    
    /**
     * Function that allows entering new information with the specified characteristics.
     * @param e Statistics data container
     * @return Returns the container with the new data
     */
    public boolean ingresarEstadistica(Estadistica e);
    
    /**
     * Function that allows entering new information with the specified characteristics.
     * @param p Character data container
     * @return Returns the container with the new data
     */
    public boolean ingresarPersonaje(Personajes p);
    
    /**
     * Function that allows entering new information with the specified characteristics.
     * @param c Data container of an account
     * @return Returns the container with the new data
     */
    public boolean ingresarCuenta(Cuentas c);
    
    /**
     * Function that allows you to delete an account with the name of the account.
     * @param nombreCuenta 
     */
    public void eliminarCuenta(String nombreCuenta);
    
    /**
     * Function that allows to obtain the saved data.
     * @return Returns the container with the data obtained.
     */
    public String obtenerDatosCuentas();
    
    /**
     * Function that allows to obtain the saved data.
     * @return Returns the container with the data obtained.
     */
    public String obtenerDatosPersonajes();
            
}
