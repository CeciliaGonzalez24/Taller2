
package taller;

public class Personajes {
    private String nombreP;
    private String rolP;
    private int cantidadSkin;
    private String nomSkin;   
    private String calidad;

    public Personajes(String nombreP, String rolP, int cantidadSkin, String nomSkin, String calidad) {
        this.nombreP = nombreP;
        this.rolP = rolP;
        this.cantidadSkin = cantidadSkin;
        this.nomSkin = nomSkin;
        this.calidad = calidad;
    }

    public String getNombreP() {
        return nombreP;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public String getRolP() {
        return rolP;
    }

    public void setRolP(String rolP) {
        this.rolP = rolP;
    }

    public int getCantidadSkin() {
        return cantidadSkin;
    }

    public void setCantidadSkin(int cantidadSkin) {
        this.cantidadSkin = cantidadSkin;
    }

    public String getNomSkin() {
        return nomSkin;
    }

    public void setNomSkin(String nomSkin) {
        this.nomSkin = nomSkin;
    }

    public String getCalidad() {
        return calidad;
    }

    public void setCalidad(String calidad) {
        this.calidad = calidad;
    }
    
    
}
