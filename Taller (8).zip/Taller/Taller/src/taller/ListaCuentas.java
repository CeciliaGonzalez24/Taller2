
package taller;

public class ListaCuentas {
    private int max;
    private Cuentas[] lc;
    private int cantidadCuentas;
    
    
    public ListaCuentas(int max) {
        this.max = max;
        cantidadCuentas = 0;
        lc = new Cuentas[max];        
    }
    
    /**
     * Function that allows adding a new container with the data.
     * @param c Container with data.
     * @return Returns a boolean according to the result.
     */
    public boolean insertar(Cuentas c){
        if(cantidadCuentas < max){
            this.lc[cantidadCuentas] = c;
            cantidadCuentas++;
            return true;
        }
        return false;
    }
    
    /**
     * Function that allows you to delete an account with the name of the account.
     * @param nombreCuenta Variable used to delete the account.
     * @return Returns a boolean according to the result obtained.
     */
    public boolean eliminarCuenta(String nombreCuenta) {
        int i = 0;
        while(i<cantidadCuentas && !lc[i].getNombreCuenta().equals(nombreCuenta)){
            i++;
        }
        if(i == cantidadCuentas) {
            //(No está la cuenta)
            return false;
        }
        else {
        //(Corrimiento de la lista)
            for(int k = i; k < cantidadCuentas-1; k++) {
                lc[k]=lc[k+1];
            }
            cantidadCuentas--;
            return true;
        }
    }

    /**
     * Function that allows you to search for the account within the list.
     * @param nombreCuenta Variable used to search within the list.
     * @return Returns the position within the list or null otherwise.
     */
    public Cuentas buscarNombreCuenta(String nombreCuenta){
        int i=0;
        while(i<cantidadCuentas&&!lc[i].getNombreCuenta().equals(nombreCuenta)){
            i++;
        }
        if(i==cantidadCuentas){
            return null;
        }
        else{
            return lc[i];
        }
    }
   
    public Cuentas getCuenta(int i) {
        if (i >= 0 && i < cantidadCuentas) {
            return lc[i];
        } else {
            return null;
        }
    }
    
    public Cuentas getNombreCuentaI(int i){
        if(i>=0&&i<cantidadCuentas){
            return lc[i];
        }
        else{
            return null;
        }
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public Cuentas[] getLc() {
        return lc;
    }

    public void setLc(Cuentas[] lc) {
        this.lc = lc;
    }

    public int getCantidadCuentas() {
        return cantidadCuentas;
    }

    public void setCantidadCuentas(int cantidadCuentas) {
        this.cantidadCuentas = cantidadCuentas;
    }
    
   

}





